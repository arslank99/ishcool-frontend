
      <div class="custom-color">
      <div class="container custom-color text-white">
        <div class="row">
          <div class="col-md-12 text-center py-1">
          <small>Copyright.2023 || Designed Project by E-learning.
            <a href="" class="" data-bs-toggle="modal" data-bs-target="#AdminLoginModal">Admin login</a></small>
          </div>
        </div>
      </div>
      </div>
<!-- Javascript -->
<script src="js/jquery.min.js"></script>
<!-- Owl Slider  -->
<script src="js/owl.carousel.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/all.min.js"></script>
<script src="js/style.js"></script>


<!-- Sign up Registration Modal -->
<!-- Modal -->
<div class="modal fade" id="RegistrationModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="RegistrationModalLabel">
          Student Registration Form
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="" method="POST" id="Registerform">
      <div class="mb-3">
          <strong>
          <i class="fas fa-user"></i>
          <label for="Name" class="form-label">Name</label>
          </strong>
          <input type="text" class="form-control" id="name" name="stuname" placeholder="Name">
        </div>
        <div class="mb-3">
          <strong>
          <i class="fas fa-envelope"></i>
          <label for="Email" class="form-label">Email address</label>
          </strong>
          <input type="email" class="form-control" id="stuemail" name="stuemail" placeholder="Email">
          <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
        </div>
      <div class="mb-3">
        <strong>
        <i class="fas fa-key"></i>
        <label for="Password" class="form-label">Password</label>
        </strong>
       <input type="password" class="form-control" id="stupassword" name="stupassword" placeholder="Password">
      </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Register</button>
      </div>
      </form>
    </div>
  </div>
</div>
<!-- Sign up Registration Modal end-->

<!-- Login User Modal Start -->
<!-- Modal -->
<div class="modal fade" id="LoginModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="LoginModalModalLabel">
         Student Login Form
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="" method="POST" id="LoginModal">
        <div class="mb-3">
          <strong>
          <i class="fas fa-envelope"></i>
          <label for="Email" class="form-label">Email address</label>
          </strong>
          <input type="email" class="form-control" id="stuemail" name="stuemail" placeholder="Email">
          <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
        </div>
      <div class="mb-3">
        <strong>
        <i class="fas fa-key"></i>
        <label for="Password" class="form-label">Password</label>
        </strong>
       <input type="password" class="form-control" id="stupassword" name="stupassword" placeholder="Password">
      </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Login</button>
      </div>
      </form>
    </div>
  </div>
</div>
<!-- Login User Modal end-->

<!-- AdminLogin Modal Start -->
<!-- Modal -->
<div class="modal fade" id="AdminLoginModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="AdminLoginModalLabel">
        Admin Login Form
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="" method="POST" id="AdminLoginModal">
        <div class="mb-3">
          <strong>
          <i class="fas fa-envelope"></i>
          <label for="AdminEmail" class="form-label">Email address</label>
          </strong>
          <input type="email" class="form-control" id="loginemailaddress" name="adminemailaddress" placeholder="Email">
        </div>
      <div class="mb-3">
        <strong>
        <i class="fas fa-key"></i>
        <label for="AdminPassword" class="form-label">Password</label>
        </strong>
       <input type="password" class="form-control" id="adminpassword" name="adminpassword" placeholder="Password">
      </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Login</button>
      </div>
      </form>
    </div>
  </div>
</div>
<!-- AdminLogin Modal end-->
</body>
</html>