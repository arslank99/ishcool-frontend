<!-- Contact Us form Start -->
<div class="container my-5" id="contact">
      <div class="row text-center my-3">
        <h1 class="col-md-12">Contact Us</h1>
      </div>
      <div class="row">
         <!-- Contact us 1st Column -->
          <div class="col-md-7">
            <form action="" method="post">
              <div class="form-group my-2">
              <input type="text" placeholder="Name" name="name" class="form-control">
              </div>
              <div class="form-group my-2">
              <input type="text" placeholder="Subject" name="subject" class="form-control">
              </div>
              <div class="form-group my-2">
              <input type="email" placeholder="Email" name="email" class="form-control">
              </div>
             <div class="form-group my-2">
             <textarea name="" id="" cols="30" rows="5" class="form-control" placeholder="Type Your Message Here"></textarea>
             </div>
              <input type="submit" value="Send" class="btn btn-danger">
            </form>
          </div>
          <!-- Contact us 2nd Column -->
          <div class="col-md-4 text-center">
            <div class="stripe">
            <h4>Ischool</h4>
              <p>Shalimar Link Road Lahore<br>
               Phone: +929955788<br>
               www.ischool.com <br>
              </p>
            </div>
          </div>
      </div>
    </div> <!-- Contact Us form end -->