<?php include"header.php";?>
<div class="container-fluid p-0 over">
    <div class="row">
        <div class="col-md-12">
        <div class="img-custom">
           <img src="images/book.jpg" alt="books">
        </div>
        </div>
    </div>
</div>
<!-- Popular Course Section -->
<div class="container my-5">
  <!-- Course heading row -->
  <div class="row">
    <div class="col-md-12 text-center">
       <h1 class="">All Course</h1>
    </div>
  </div>
  <!-- course card 1st row -->
<div class="row">
<div class="col-sm-6 col-md-6 col-lg-4">
  <div class="card mt-3">
    <img src="images/guitar.jpg" class="card-img-top img-fluid" alt="image">
    <div class="card-body">
      <h5 class="card-title">Learn Guitar Easy Way</h5>
      <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    </div>
    <div class="card-footer d-flex justify-content-between">
      <p class="card-text d-inline">Price: <small><del>2000</del><span><b>1800</b></span></small></p>
      <a href="course-detail.php" class="btn btn-primary ">Enroll</a>
    </div>
  </div>
</div>
<div class="col-sm-6 col-md-6 col-lg-4">
  <div class="card mt-3">
    <img src="images/guitar.jpg" class="card-img-top img-fluid" alt="image">
    <div class="card-body">
      <h5 class="card-title">Learn Guitar Easy Way</h5>
      <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    </div>
    <div class="card-footer d-flex justify-content-between">
      <p class="card-text d-inline">Price: <small><del>2000</del><span><b>1800</b></span></small></p>
      <a href="" class="btn btn-primary ">Enroll</a>
    </div>
  </div>
</div>
<div class="col-sm-6 col-md-6 col-lg-4">
  <div class="card mt-3">
    <img src="images/guitar.jpg" class="card-img-top img-fluid" alt="image">
    <div class="card-body">
      <h5 class="card-title">Learn Guitar Easy Way</h5>
      <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    </div>
    <div class="card-footer d-flex justify-content-between">
      <p class="card-text d-inline">Price: <small><del>2000</del><span><b>1800</b></span></small></p>
      <a href="" class="btn btn-primary ">Enroll</a>
    </div>
  </div>
</div>
</div>
<!-- course card 2nd row -->
<div class="row">
<div class="col-sm-6 col-md-6 col-lg-4">
  <div class="card mt-3">
    <img src="images/guitar.jpg" class="card-img-top img-fluid" alt="image">
    <div class="card-body">
      <h5 class="card-title">Learn Guitar Easy Way</h5>
      <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    </div>
    <div class="card-footer d-flex justify-content-between">
      <p class="card-text d-inline">Price: <small><del>2000</del><span><b>1800</b></span></small></p>
      <a href="" class="btn btn-primary ">Enroll</a>
    </div>
  </div>
</div>
<div class="col-sm-6 col-md-6 col-lg-4">
  <div class="card mt-3">
    <img src="images/guitar.jpg" class="card-img-top img-fluid" alt="image">
    <div class="card-body">
      <h5 class="card-title">Learn Guitar Easy Way</h5>
      <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    </div>
    <div class="card-footer d-flex justify-content-between">
      <p class="card-text d-inline">Price: <small><del>2000</del><span><b>1800</b></span></small></p>
      <a href="" class="btn btn-primary ">Enroll</a>
    </div>
  </div>
</div>
<div class="col-sm-6 col-md-6 col-lg-4">
  <div class="card mt-3">
    <img src="images/guitar.jpg" class="card-img-top img-fluid" alt="image">
    <div class="card-body">
      <h5 class="card-title">Learn Guitar Easy Way</h5>
      <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    </div>
    <div class="card-footer d-flex justify-content-between">
      <p class="card-text d-inline">Price: <small><del>2000</del><span><b>1800</b></span></small></p>
      <a href="" class="btn btn-primary ">Enroll</a>
    </div>
  </div>
</div>
  </div>
</div><!-- Popular Course Section End -->
<?php include"contact.php";?>
<?php include"footer.php";?>
<!-- footer end -->

