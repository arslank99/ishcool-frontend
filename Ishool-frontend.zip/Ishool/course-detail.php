<?php include"header.php"?>
<div class="container-fluid p-0 over">
    <div class="row">
        <div class="col-md-12">
        <div class="img-custom">
           <img src="images/book.jpg" alt="books">
        </div>
        </div>
    </div>
</div>
<div class="container my-4">
    <div class="row">
        <div class="col-md-4">
            <img src="images/guitar.jpg" alt="" class="card-img-top">
        </div>
        <div class="col-md-8">
            <div class="card-body">
                <h5 class="card-title mb-1 fw-bolder">Course Name : Learn Guitar</h5>
                <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Totam consequatur ipsum incidunt minus, expedita eum aspernatur rem. A accusantium nulla deserunt modi delectus quisquam commodi quibusdam, aspernatur voluptate, eligendi velit?</p>
                <p class="card-text fw-bolder">Duration : 10 days</p>
                <form action="" method="POST">
                 <p class="card-text d-inline fw-bolder">Price : <small>
                    <del>2000</del></small><span class="mx-2 fw-bolder">200</span>
                </p>
                <input type="submit" class="btn btn-primary text-white float-end"
                value="Buy Now">
                </form>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">
           <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Lesson.No</th>
                        <th>Lesson Name</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>Introduction</td>
                    </tr>
                </tbody>
           </table>
        </div>
    </div>
</div>
<?php include"footer.php"?>